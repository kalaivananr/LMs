# leaveManagmentSyatem
This was a off the shelf software and small part of an ERP project called Leave Management System. This module is specially design for employee leave management flow. This is completely my own development project. I develop it throughout the scratch.
